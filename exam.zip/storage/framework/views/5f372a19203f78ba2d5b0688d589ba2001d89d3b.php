
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>New Status</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('status.store')); ?>">
                        <div class="form-group">
                            <label>Status name:</label>
                            <input type="text" class="form-control" name="status_name" value="<?php echo e(old('status_name')); ?>">
                            <small class="form-text text-muted">Please enter status name.</small>
                        </div>
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-primary crud" type="submit" title="add"><i class="fas fa-check"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/status/create.blade.php ENDPATH**/ ?>