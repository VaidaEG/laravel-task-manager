
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>New Task</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('task.store')); ?>">
                        <div class="form-group">
                            <label>Name:</label>
                            <input type="text" class="form-control" name="task_name" value="<?php echo e(old('task_name')); ?>">
                            <small class="form-text text-muted">Please enter task name.</small>
                        </div>
                        <div class="form-group">
                            <label>Description:</label>
                            <textarea id="summernote" name="task_description"><?php echo e(old('task_description')); ?></textarea>
                            <small class="form-text text-muted">Please enter more information about task.</small>
                        </div>
                        <div class="form-group">
                            <label>Created:</label>
                            <input type="datetime-local" class="form-control" name="add_date" value="<?php echo e(old('add_date')); ?>">
                            <small class="form-text text-muted">Please enter current date.</small>
                        </div>
                        <div class="form-group">
                            <label>Deadline:</label>
                            <input type="datetime-local" class="form-control" name="completed_date" value="<?php echo e(old('completed_date')); ?>">
                            <small class="form-text text-muted">Please choose deadline date.</small>
                        </div>
                        <div class="form-group">
                            <label>Select status:</label>
                            <select class="form-control body-select" name="status_id">
                                <option value="0" disabled selected>Select status</option>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                            <small class="form-text text-muted">Please choose status for task.</small>
                        </div>
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-primary crud" type="submit" title="add"><i class="fas fa-check"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
window.addEventListener('DOMContentLoaded', (event) => {
    $('#summernote').summernote();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/task/create.blade.php ENDPATH**/ ?>