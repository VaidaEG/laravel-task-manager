
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2>Status List <i class="fas fa-user"></i></h2>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-line d-flex justify-content-between color">
                            <div class="list-content">
                                <h5><?php echo e($status->name); ?></h5>
                            </div>
                            <div class="d-flex justify-content-center buttons">
                                <a href="<?php echo e(route('status.edit', [$status])); ?>" class="btn btn-primary crud mr-3" title="edit"><i class="fas fa-edit"></i></a>
                                <form style="display: inline-block;" method="POST" action="<?php echo e(route('status.destroy', [$status])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger" type="submit" title="delete"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/status/index.blade.php ENDPATH**/ ?>