
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2>Task List <i class="fas fa-tasks"></i></h2>
                    <form action="<?php echo e(route('task.index')); ?>" method="get" class="make-inline">
                        <label>Tasks: </label>
                        <div class="form-group form-inline d-flex justify-content-between">
                            <select class="form-control header-select" name="status_id">
                                <option value="0" disabled <?php if($filterBy == 0): ?> selected <?php endif; ?>>Select status</option>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status->id); ?>" <?php if($filterBy == $status->id): ?> selected <?php endif; ?>>
                                        <?php echo e($status->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="d-flex justify-content-center buttons">
                            <button type="submit" class="btn btn-primary crud mr-3" title="filter"><i class="fas fa-search"></i></button>
                            <a class="btn btn-primary crud" href="<?php echo e(route('task.index')); ?>" title="clear filter"><i class="fas fa-times-circle"></i></a>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item list-line d-flex justify-content-between color">
                            <div class="list-content">
                                <h5><?php echo e($task->task_name); ?></h5>
                                <p>Task description: <?php echo $task->task_description; ?></p>
                                <p>Date created: <?php echo e($task->add_date); ?></p>
                                <p>Deadline: <?php echo e($task->completed_date); ?></p>
                            </div>
                            <div class="d-flex justify-content-center buttons">
                                <a href="<?php echo e(route('task.pdf', [$task])); ?>" class="btn btn-primary crud mr-3" type="submit" title="pdf"><i class="fas fa-file-pdf"></i></button>
                                <a class="btn btn-primary crud mr-3" href="<?php echo e(route('task.edit',[$task])); ?>" title="edit"><i class="fas fa-edit"></i></a>
                                <form style="display: inline-block;" method="POST" action="<?php echo e(route('task.destroy', [$task])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger" type="submit" title="delete"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/task/index.blade.php ENDPATH**/ ?>