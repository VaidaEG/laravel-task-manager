<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title><?php echo e($task->name); ?></title>
        <style>
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            src: url(<?php echo e(asset('fonts/Roboto-Regular.ttf')); ?>);
            }
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: bold;
            src: url(<?php echo e(asset('fonts/Roboto-Bold.ttf')); ?>);
            }
            body {
                font-family: 'Roboto';
            }
        </style>
    </head>
    <body>
        <h1 style="text-align: center;"><?php echo e($task->task_name); ?></h1>
        <h3><?php echo e($task->taskStatus->name); ?></h3>
        <p>Created: <?php echo e($task->add_date); ?></p>
        <p>Deadline: <?php echo e($task->completed_date); ?></p>
        <p style="text-align: center;"><?php echo $task->task_description; ?></p>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/task/pdf.blade.php ENDPATH**/ ?>