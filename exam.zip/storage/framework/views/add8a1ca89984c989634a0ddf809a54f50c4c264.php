<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title><?php echo e($status->name); ?></title>
        <style>
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: 400;
            src: url(<?php echo e(asset('fonts/Roboto-Regular.ttf')); ?>);
            }
            @font-face {
            font-family: 'Roboto';
            font-style: normal;
            font-weight: bold;
            src: url(<?php echo e(asset('fonts/Roboto-Bold.ttf')); ?>);
            }
            body {
                font-family: 'Roboto';
            }
        </style>
    </head>
    <body>
        <h1><?php echo e($status->name); ?></h1>
        <h3><?php echo e($status->statusTasksList->task_name); ?></h3>
        <p>Created: <?php echo e($status->statusTasksList->add_date); ?></p>
        <p>Deadline: <?php echo e($status->statusTasksList->completed_date); ?></p>
        <p><?php echo $status->statusTasksList->task_description; ?></p>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\php-laravel\exam\resources\views/status/pdf.blade.php ENDPATH**/ ?>